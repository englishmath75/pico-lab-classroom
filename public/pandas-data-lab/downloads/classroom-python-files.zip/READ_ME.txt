DATA DETECTIVE Python practice
Extract all files into one folder. Open that folder in VS Code and run the .py files there.
Lesson 03 reads sports_fictional.csv. Other basic lessons create small fictional tables in code.
Requirements: pandas, matplotlib.
